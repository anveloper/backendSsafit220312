package com.ssafit.model;

public class MainController {
// 뭘 써야할 지 아직 모르겠습니다.
}
